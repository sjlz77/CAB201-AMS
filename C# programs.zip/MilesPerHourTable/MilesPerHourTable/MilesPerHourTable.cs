﻿using System;

public class MilesPerHourTable
{
    public static void Main()
    {

      
        while (true)
        {
            int result;
            int a = 15;

            Console.Write("enter row count or quit(q): ");

            string reply = Console.ReadLine();

            if (reply == "q")
            {
                break;
            }
            else
            {
                result = Convert.ToInt32(reply);



                Console.WriteLine("MPH\tKPH"); 


                Console.WriteLine(string.Format("{0,-7} {1,-7}", a.ToString(), Math.Round((a * 1.609344), 2).ToString()));

                    result -= 1;

                    a = a + 10;
    
                
            }
        }
    }
}