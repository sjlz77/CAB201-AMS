﻿using System;
public class Matrix
{
    public static void Main()
    {
        int rows, columns, number;

        Console.WriteLine("What is the matrix row count?");
        rows = int.Parse(Console.ReadLine());

        Console.WriteLine("What is the matrix column count?");
        columns = int.Parse(Console.ReadLine());

        Console.WriteLine("What is your number?");
        number = int.Parse(Console.ReadLine());

        Console.WriteLine(number + " is in row " + number / columns + " and column " + number % columns);
        Console.ReadLine();
    }
}