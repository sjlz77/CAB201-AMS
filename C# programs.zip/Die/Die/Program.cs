﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DieRoller
{
    public class Die
    {
        private int numFaces;
        private int faceValue;

        public Die()
        {
            numFaces = 6;
            faceValue = 1;
        }

        public Die(int faces)
        {
            if(faces >= 3) {

                numFaces = faces;

            } else
            {

                numFaces = 6;

            }

            faceValue = 1;

        }


        public void RollDie()
        {
            Random random = new Random();
            faceValue = random.Next(1, numFaces + 1);
        }

        public int GetFaceValue()
        {
            return faceValue;
        }

        public int GetNumFaces()
        {
            return numFaces;
        }

    }

}