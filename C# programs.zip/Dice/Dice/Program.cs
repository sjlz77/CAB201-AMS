﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DiceRoller
{

    public class Die
    {
        private int numFaces;
        private int faceValue;

        public Die()
        {
            numFaces = 6;
            faceValue = 1;
        }

        public Die(int faces)
        {
            if (faces >= 3)
            {

                numFaces = faces;

            }
            else
            {

                numFaces = 6;

            }

            faceValue = 1;
        }

        public void RollDie()
        {
            Random random = new Random();
            faceValue = random.Next(1, numFaces + 1);
        }

        public int GetFaceValue()
        {
            return faceValue;
        }

        public int GetNumFaces()
        {
            return numFaces;
        }
        // You should include your Die class from the previous exercise here
    }// end class Die

    public class Dice
    {
        // Implement your 'Dice' class here
        // ...
        private Die[] d;


        public Dice(int dice)
        {

            d = new Die[dice];

            //iterate through the whole array and create and store a new object
            for (int i = 0; i < d.Count(); i++)
            {
                d[i] = new Die();
            }
        }


        public Dice(int dice, int faces)
        {
            d = new Die[dice];


            //iterate through the whole array and create and store a new object

            for (int i = 0; i < d.Count(); i++)
            {
                d[i] = new Die(faces);

            }


        }

        //rolls all die in array d
        public void RollDice()

        {

            //iterate through the whole array and roll each die

            for (int i = 0; i < d.Count(); i++)
            {
                d[i].RollDie();

            }

        }

        //return sum of face values
        public int GetFaceValue()

        {
            int totalFaceValue = 0;

            //iterate through the whole array and add face values

            for (int i = 0; i < d.Count(); i++)
            {
                totalFaceValue = totalFaceValue + d[i].GetFaceValue();

            }


            return totalFaceValue;
        }
    }// end class Dice

}