﻿using System;
public class StringOrder
{
    enum Order { Precedes = -1, Equals = 0, Follows = 1 };

    public static void Main()
    {
        string nameA;
        string nameB;

        Console.WriteLine("What is name A?");
        nameA = Console.ReadLine().Replace("Name: ", "");

        Console.WriteLine("What is name B?");
        nameB = Console.ReadLine().Replace("Name: ","");

        Console.WriteLine(nameA + " " + Enum.GetName(typeof(Order), nameA .CompareTo(nameB)) + " " + nameB);
        Console.ReadLine();

    }
}
