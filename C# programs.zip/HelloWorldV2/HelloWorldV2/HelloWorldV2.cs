﻿using System;

public class HelloWorldV2
{
    public static void Main()
    {
        // Declare a 'string' variable called 'name' to hold the user's name
        string Name;
        // ...

        // Display the message "Please enter your name: ".
        Console.Write("Please enter your name: ");
        // (hint: Use Console.Write instead of WriteLine for this)
        // ...

        // Use Console.ReadLine to read what the user types into the 'name' variable
        // ...
        Name = Console.ReadLine();
        // Write a single blank line
        // ...
        Console.WriteLine();
        // Write "Hello (name goes here), and welcome to CAB201" on a line by itself.
        Console.WriteLine("Hello " + Name + ", and welcome to CAB201");
        Console.ReadLine();
        // Instead of (name goes here) you should put in the name the user gave you.
        // ...
    }
}