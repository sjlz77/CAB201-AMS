﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompoundInterestCalculator
{
    public class CompoundCalculator
    {
        const int EXIT = 0;
        const int CALCULATE_DAILY = 1;
        const int CALCULATE_QUARTERLY = 2;
        const int CALCULATE_VARIABLE = 3;
        const int NUM_OPTIONS = 3;
        public static void Main(string[] args)
        {
            int menuOption;
            WelcomeMessage();
            do
            {
                DisplayMenu();
                menuOption = ReadOption();

                if (menuOption != EXIT)
                {
                    double finalAmount = CalculateInterest(menuOption);
                    OutputResult(finalAmount);
                }
            } while (menuOption != EXIT);

            ExitProgram();
        }

        public static void WelcomeMessage()
        {
            Console.Write("\n\n\tCompound Intrest Calculator");
        }

        public static void ExitProgram()
        {
            Console.WriteLine("\n\nPress enter to exit.");
            Console.ReadLine();
        }

        static void DisplayMenu()
        {
            string menu = "\n\n1) Calculate final amount after interest compounded daily"
            + "\n2) Calculate final amount after interest (compounded quarterly)"
            + "\n3) Calculate final amount after interest (define number of times compounded yearly)"
            + "\n\nEnter your option(1-3 or 0 to exit): ";
            Console.Write(menu);
        }
        public static void OutputResult(double finalAmount)
        {
            Console.WriteLine("\n\nThe final amount of money plus interest is: " + finalAmount.ToString("C2"));
        }

        static int ReadOption()
        {
            string choice;
            int option;
            bool okayChoice;

            do
            {
                choice = Console.ReadLine();
                okayChoice = int.TryParse(choice, out option);
                if (!okayChoice || option < 0 || option > NUM_OPTIONS)
                {
                    okayChoice = false;
                    Console.WriteLine("You did not enter a correct option.\n\nPlease try again.");
                    DisplayMenu();
                }
            } while (!okayChoice);
            return option;
        }
        public static double CalculateInterest(int menuOption)
        {
            double principal;
            double interestRate;
            int numYears;
            double finalAmount;

            Console.Write("Enter the principal amount: ");
            principal = Double.Parse(Console.ReadLine());

            Console.Write("Enter the interest rate: ");
            interestRate = Double.Parse(Console.ReadLine());

            Console.Write("Enter the number of years that interest is accumulated for: ");
            numYears = Int32.Parse(Console.ReadLine());

            if (menuOption == CALCULATE_DAILY || menuOption == CALCULATE_QUARTERLY)
            {
                if (menuOption == CALCULATE_DAILY)
                {
                    finalAmount = CalculateCompoundInterest(principal, interestRate, numYears);
                }
                else
                {
                    finalAmount = CalculateCompoundInterest(principal, interestRate, numYears, 4);
                }
            }
            else
            {
                Console.Write("Enter the number of times the interest is compounded yearly: ");
                int numTimesCompounded = Int32.Parse(Console.ReadLine());
                finalAmount = CalculateCompoundInterest(principal, interestRate, numYears, numTimesCompounded);
            }
            Console.WriteLine();
            return finalAmount;
        }
        public static double CalculateCompoundInterest(double principal, double interestRate, int numYears)
        {
            double amount;
            amount = (principal * Math.Pow((1 + interestRate / 365), numYears * 365));
            return amount;
        }

        public static double CalculateCompoundInterest(double principal, double interestRate, int numYears, int numTimes)
        {
            double amount;
            amount = (principal * Math.Pow((1 + interestRate / numTimes), numYears * numTimes));
            return amount;
        }
    }
}
