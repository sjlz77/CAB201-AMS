﻿using System;
    class IncomeTax
    {
        public static void Main()
        {
            int tI, nCd, nI;
            double tA;


    Income:



            Console.Write("What is your total income: ");
            string i = Console.ReadLine();
            if (!int.TryParse(i, out tI))
            {
                Console.WriteLine("Enter your income as a whole-dollar figure.");
                goto Income;
            }
            else if (tI < 0)
            {
                Console.WriteLine("Your income cannot be negative.");
                goto Income;
            }


        Child:


            Console.Write("How many children do you have: ");
            string c = Console.ReadLine();
            if (!int.TryParse(c, out nCd))
            {
                Console.WriteLine("You must enter a valid number.");
                goto Child;
            }
            else if (nCd < 0)
            {
                Console.WriteLine("You must enter a positive number.");
                goto Child;
            }

            nI = tI - (10000 + nCd * 2000);
            tA = nI * .02;
            string tAA = tA.ToString("N2");

        if (tA <= 0)
            {
                Console.WriteLine("You owe no tax.");
            }
            else
            {
            Console.WriteLine("You owe a total of $" +tAA+ " tax");
            }

            Console.WriteLine("\n\n Hit Enter to exit.");
            Console.ReadLine();
        }
    }