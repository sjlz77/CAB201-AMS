﻿using System;


namespace MatrixLibrary
{
    class Program
    {

        public static string MatrixToString(int[,] arr)
        {
            int rowLength = arr.GetLength(0);
            int colLength = arr.GetLength(1);
            string res = "";


            for (int i = 0; i < rowLength; i++)
            {
                for (int j = 0; j < colLength; j++)
                {
                    res = res + string.Format("{0,-4}", arr[i, j]);
                }
                res = res + "\n";
            }
            return res;
        }
        public static int[,] MatrixMultiply(int[,] a, int[,] b)
        {
            int m = a.GetLength(0);

            int n = a.GetLength(1);

            int q = b.GetLength(1);

            int[,] c = new int[m, q];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < q; j++)
                {
                    c[i, j] = 0;
                    for (int k = 0; k < n; k++)
                    {
                        c[i, j] += a[i, k] * b[k, j];
                    }
                }
            }
            return c;
        }

        static void Main(string[] args)
        {
            int[,] matrix = new int[,]
            {

   {1, 2},

   {3, 4},

            };
            Console.WriteLine("Printing the matrix :{1, 2}, {3, 4}\n");
            Console.WriteLine(MatrixToString(matrix));

            int[,] mult = MatrixMultiply(matrix, matrix);
            Console.WriteLine("Multiplying the matrix :{1, 2}, {3, 4} by itself\n");
            Console.WriteLine(MatrixToString(mult));
            Console.ReadLine();
        }
    }
}