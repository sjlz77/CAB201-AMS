﻿using System;
using System.Collections.Generic;
using System.Text;
class Sequence
    {

    public static string[] Kmers(int k, string DNA)

    {


        List<string> Kmers = new List<string>();

        int n = DNA.Length;


        for (int i = 0; i < n - k + 1; i++)

        {

            Kmers.Add(DNA.Substring(i, k));

        }


        return Kmers.ToArray();

    }


    public static void ReverseComplement(ref string DNA)

    {


        int n = DNA.Length;


        var reverse_str = new StringBuilder(n);

        for (var i = n - 1; i > -1; i--)

        {

            switch (DNA[i])

            {

                case 'A':

                    reverse_str.Append('T');

                    break;

                case 'T':

                    reverse_str.Append('A');

                    break;

                case 'G':

                    reverse_str.Append('C');

                    break;

                case 'C':

                    reverse_str.Append('G');

                    break;

            }

        }

        DNA = reverse_str.ToString();

    }

    public static bool Dyad(string DNA, int minimum = 5)

    {

        int n = DNA.Length;

  
        int str_len = (n - minimum) / 2;

        var strDNA = DNA.Substring(0, str_len);

        ReverseComplement(ref strDNA);

        if (strDNA.Equals(DNA.Substring(n - str_len, str_len)))

            return true;

        else

            return false;

    }
}