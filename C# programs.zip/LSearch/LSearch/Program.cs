﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Linear_Search
{
    class Program
    {


        static void Main(string[] args)
        {

            const string Start_Message = "\n\tWelcome to Linear Search Demonstration\n"
            + "\n The array contains the following 9 words:\n\n";

            string[] words = {"the", "quick", "brown", "fox",
"jumps", "over", "the", "lazy", "dog"};

            int location;

            OutputMessage(Start_Message);
            DisplayArray(words);

            location = LinearSearch(words, "the");
            OutputSearchResult(location, "the");

            location = LinearSearch(words, "able");
            OutputSearchResult(location, "able");


            location = LinearSearch(words, "over");
            OutputSearchResult(location, "over");

            location = LinearSearch(words, "zebra");
            OutputSearchResult(location, "zebra");

            location = LinearSearch(words, "dog");
            OutputSearchResult(location, "dog");

            ExitProgram();

        } //end Main


        /**Implemented LinearSearch algorithm */
        public static int LinearSearch(string[] words, string word)
        {

            int position = 0;

            /*Run while until the word is not matched*/
            while ((position < words.Length) && (words[position] != word))
            {
                //increment the position by 1
                position++;
            }


            if (position < words.Length)
                return position; // found it
            else
                return -1; // key not in the list

        } //end LinearSearch

        static void DisplayArray(string[] words)
        {

            foreach (string element in words)
            {
                OutputMessage("\t" + element + "\n");
            }
            Console.WriteLine();

        }//end DisplayArray

        static void OutputSearchResult(int position, string word)
        {
            string continueMessage = "\nPress any key to continue:";

            if (position < 0)
            {
                Console.WriteLine("the word \"{0}\" not found in the list\n ", word);
            }
            else
            {
                Console.WriteLine("the word \"{0}\" found in position {1} in the list\n", word, position);
            }

            OutputMessage(continueMessage);
            Console.ReadKey();

        } //end OutputSearchResult

        static void OutputMessage(string s)
        {
            Console.Write(s);
        }// end OutPutMessage

        static void ExitProgram()
        {
            OutputMessage("\n\nPress any key to exit program: ");
            Console.ReadKey();
        }//end ExitProgram

    }//end class
}//end namespace